package com.streeraksha.myapplication1.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class LocationUtil {

    public interface LocationCallback {
        void onLocationResult(String locationLink);
    }

    @SuppressLint("MissingPermission")
    public static void getLocation(Context context, LocationCallback callback) {

        FusedLocationProviderClient client =
                LocationServices.getFusedLocationProviderClient(context);

        client.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                String link = "https://maps.google.com/?q="
                        + location.getLatitude() + ","
                        + location.getLongitude();
                callback.onLocationResult(link);
            } else {
                Toast.makeText(context,
                        "Location unavailable. Turn ON GPS.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
