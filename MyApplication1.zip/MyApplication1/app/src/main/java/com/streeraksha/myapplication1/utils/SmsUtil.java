package com.example.myapplication.utils;

import android.telephony.SmsManager;

public class SmsUtil {

    public static void sendSOS(String phoneNumber, String locationLink) {

        String message =
                "🚨 SOS ALERT 🚨\n" +
                        "I am in danger.\n" +
                        "My live location:\n" +
                        locationLink;

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
        );
    }
}
