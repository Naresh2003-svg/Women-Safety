package com.streeraksha.myapplication1;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.streeraksha.myapplication1.utils.LocationUtil;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private MaterialButton sosButton, selectContactButton, stopSirenButton;
    private MaterialCardView sosOuterRing;
    private ExtendedFloatingActionButton fabAiChat; // Added for AI Help
    private MediaPlayer sirenPlayer;
    private Vibrator vibrator;

    private static final int LOCATION_PERMISSION = 101;
    private static final int CONTACT_PERMISSION = 102;

    private Set<String> selectedContacts = new HashSet<>();
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize Premium UI Elements
        sosButton = findViewById(R.id.btnSOS);
        sosOuterRing = findViewById(R.id.sosOuterRing);
        selectContactButton = findViewById(R.id.btnSelectContact);
        stopSirenButton = findViewById(R.id.btnStopSiren);
        fabAiChat = findViewById(R.id.fabAiChat); // Initialize AI Button

        // 2. Initialize Services
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        prefs = getSharedPreferences("EmergencyContacts", MODE_PRIVATE);
        selectedContacts = new HashSet<>(prefs.getStringSet("contacts", new HashSet<>()));

        // 3. Setup Initial State
        initSiren();
        applyPremiumAnimations();

        // 4. Click Listeners with Haptic Feedback
        selectContactButton.setOnClickListener(v -> {
            triggerHapticFeedback();
            selectContact();
        });

        stopSirenButton.setOnClickListener(v -> {
            triggerHapticFeedback();
            stopSiren();
        });

        sosButton.setOnClickListener(v -> {
            triggerHapticFeedback();
            handleSOSClick();
        });

        // AI Chat Button Listener
        fabAiChat.setOnClickListener(v -> {
            triggerHapticFeedback();
            Intent intent = new Intent(MainActivity.this, ChatBotActivity.class);
            startActivity(intent);
            // Premium slide transition
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });
    }

    private void handleSOSClick() {
        if (selectedContacts.isEmpty()) {
            Toast.makeText(this, "Please add emergency contacts first", Toast.LENGTH_SHORT).show();
            return;
        }

        if (hasAllPermissions()) {
            triggerSOS();
        } else {
            requestPermissions();
        }
    }

    private void initSiren() {
        sirenPlayer = MediaPlayer.create(this, Settings.System.DEFAULT_ALARM_ALERT_URI);
        if (sirenPlayer != null) {
            sirenPlayer.setLooping(true);
        }
    }

    private void applyPremiumAnimations() {
        try {
            Animation pulse = AnimationUtils.loadAnimation(this, R.anim.pulse_premium);
            sosOuterRing.startAnimation(pulse);
        } catch (Exception e) {
            Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
            fadeIn.setDuration(1000);
            fadeIn.setRepeatMode(Animation.REVERSE);
            fadeIn.setRepeatCount(Animation.INFINITE);
            sosOuterRing.startAnimation(fadeIn);
        }
    }

    private void triggerHapticFeedback() {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(50);
        }
    }

    // --- CONTACT LOGIC ---
    private void selectContact() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, CONTACT_PERMISSION);
            return;
        }
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, CONTACT_PERMISSION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CONTACT_PERMISSION && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String phone = cursor.getString(index).replaceAll("[\\s\\-()]", "");
                cursor.close();

                selectedContacts.add(phone);
                prefs.edit().putStringSet("contacts", selectedContacts).apply();
                Toast.makeText(this, "Contact added: " + phone, Toast.LENGTH_SHORT).show();
            }
        }
    }

    // --- PERMISSION LOGIC ---
    private boolean hasAllPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CALL_PHONE},
                LOCATION_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == LOCATION_PERMISSION) triggerSOS();
        } else {
            Toast.makeText(this, "Permissions are required for safety features.", Toast.LENGTH_LONG).show();
        }
    }

    // --- SOS CORE ACTIONS ---
    private void triggerSOS() {
        startSiren();
        sosButton.setText("ALERTING");

        LocationUtil.getLocation(this, locationLink -> {
            for (String phone : selectedContacts) {
                String message = "🚨 SOS ALERT 🚨\nI am in danger. My location:\n" + locationLink;
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone));
                smsIntent.putExtra("sms_body", message);
                startActivity(smsIntent);
            }

            Iterator<String> iterator = selectedContacts.iterator();
            if (iterator.hasNext()) {
                Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + iterator.next()));
                startActivity(callIntent);
            }

            sosButton.setText("SOS");
        });
    }

    private void startSiren() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) {
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        }
        if (sirenPlayer != null && !sirenPlayer.isPlaying()) {
            sirenPlayer.start();
        }
    }

    private void stopSiren() {
        if (sirenPlayer != null && sirenPlayer.isPlaying()) {
            sirenPlayer.stop();
            sirenPlayer.release();
            initSiren();
            Toast.makeText(this, "Siren Stopped", Toast.LENGTH_SHORT).show();
        }
    }
}