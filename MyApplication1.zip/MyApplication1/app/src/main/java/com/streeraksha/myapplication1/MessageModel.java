package com.streeraksha.myapplication1;

public class MessageModel {
    public static final int SENT_BY_USER = 0;
    public static final int SENT_BY_BOT = 1;

    private String message;
    private int sentBy;

    public MessageModel(String message, int sentBy) {
        this.message = message;
        this.sentBy = sentBy;
    }

    public String getMessage() { return message; }
    public int getSentBy() { return sentBy; }
}