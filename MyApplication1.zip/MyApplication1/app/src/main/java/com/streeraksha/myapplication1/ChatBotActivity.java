package com.streeraksha.myapplication1;

import android.os.Bundle;
import android.os.Handler;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class ChatBotActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText etMessage;
    private FloatingActionButton btnSend;
    private ChatAdapter adapter;
    private List<MessageModel> messageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        recyclerView = findViewById(R.id.chatRecyclerView);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        // Set up RecyclerView
        adapter = new ChatAdapter(messageList);
        recyclerView.setAdapter(adapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true); // Gemini style: scroll to bottom
        recyclerView.setLayoutManager(llm);

        btnSend.setOnClickListener(v -> {
            String question = etMessage.getText().toString().trim();
            if(!question.isEmpty()) {
                addToChat(question, MessageModel.SENT_BY_USER);
                etMessage.setText("");
                simulateBotResponse(question);
            }
        });

        // Initial Greeting
        addToChat("Hello! I am your Raksha AI. How can I assist you?", MessageModel.SENT_BY_BOT);
    }

    private void addToChat(String message, int sentBy) {
        runOnUiThread(() -> {
            messageList.add(new MessageModel(message, sentBy));
            adapter.notifyItemInserted(messageList.size() - 1);
            recyclerView.scrollToPosition(messageList.size() - 1);
        });
    }

    private void simulateBotResponse(String userText) {
        new Handler().postDelayed(() -> {
            String response = "I'm analyzing your request... For safety, always stay in well-lit areas.";
            if(userText.toLowerCase().contains("help")) response = "If you are in danger, please use the SOS button on the home screen immediately!";
            addToChat(response, MessageModel.SENT_BY_BOT);
        }, 1000);
    }
}