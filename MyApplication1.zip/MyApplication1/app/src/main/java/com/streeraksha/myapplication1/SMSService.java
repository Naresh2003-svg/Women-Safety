package com.streeraksha.myapplication1;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.SmsManager;
import androidx.core.app.NotificationCompat;
import java.util.HashSet;
import java.util.Set;

public class SMSService extends Service {
    private Handler handler = new Handler();
    private Runnable smsRunnable;
    private static final int INTERVAL = 30000; // 30 Seconds

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, "safety_channel")
                .setContentTitle("Stree Raksha Active")
                .setContentText("Auto-SMS updates are enabled every 30s")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setOngoing(true)
                .build();

        // Start as Foreground Service to prevent background killing
        startForeground(1, notification);

        startAutoSmsTask();
        return START_STICKY;
    }

    private void startAutoSmsTask() {
        smsRunnable = new Runnable() {
            @Override
            public void run() {
                sendEmergencySms();
                handler.postDelayed(this, INTERVAL);
            }
        };
        handler.post(smsRunnable);
    }

    private void sendEmergencySms() {
        try {
            Set<String> contacts = getSharedPreferences("EmergencyContacts", MODE_PRIVATE)
                    .getStringSet("contacts", new HashSet<>());

            SmsManager smsManager = SmsManager.getDefault();
            String message = "🚨 AUTO-UPDATE: I am still in an emergency. My app is tracking my status.";

            for (String phone : contacts) {
                smsManager.sendTextMessage(phone, null, message, null, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "safety_channel", "Safety Service", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(smsRunnable);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}